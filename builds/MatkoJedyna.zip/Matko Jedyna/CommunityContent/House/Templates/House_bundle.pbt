Assets {
  Id: 11569999446439534831
  Name: "House"
  PlatformAssetType: 5
  TemplateAsset {
    ObjectBlock {
      RootId: 9376352595367268041
      Objects {
        Id: 9376352595367268041
        Name: "TemplateBundleDummy"
        Transform {
          Location {
          }
          Rotation {
          }
          Scale {
            X: 1
            Y: 1
            Z: 1
          }
        }
        CameraCollidable {
          Value: "mc:ecollisionsetting:inheritfromparent"
        }
        Folder {
          BundleDummy {
            ReferencedAssets {
              Id: 13537859575716908234
            }
          }
        }
        NetworkRelevanceDistance {
          Value: "mc:eproxyrelevance:critical"
        }
        IsReplicationEnabledByDefault: true
      }
    }
    PrimaryAssetId {
      AssetType: "None"
      AssetId: "None"
    }
  }
  Marketplace {
    Id: "a885f26bf96841348f40986695673361"
    OwnerAccountId: "bdde6f83d6e945c69269b1d0d9d120e8"
    OwnerName: "Knightova"
    Version: "1.0.0"
    Description: "House similar to one from Pallet town. 2 Story house. No Rooms"
  }
  SerializationVersion: 125
}
