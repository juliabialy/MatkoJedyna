Assets {
  Id: 14167104203695992180
  Name: "Virtual Folders"
  PlatformAssetType: 30
  SerializationVersion: 125
  VirtualFolderSetAsset {
  }
}
