MetaVersion: 1
MarketplaceDetails {
  Id: "57a1110c2c0d4b97b0061188210baf54"
  OwnerAccountId: "4d64fe2c095a45ab905923395d72f51e"
  OwnerName: "mrbigfists"
  Version: "1.0.0"
}
AssetIdsOriginalToNew {
  key: 3131902176100994190
  value: 15395524286032227083
}
AssetIdsOriginalToNew {
  key: 8699301711134835968
  value: 1030112355598126618
}
