Assets {
  Id: 5564134552912882304
  Name: "FARM HOUSE"
  PlatformAssetType: 5
  TemplateAsset {
    ObjectBlock {
      RootId: 3629166120247307214
      Objects {
        Id: 3629166120247307214
        Name: "TemplateBundleDummy"
        Transform {
          Location {
          }
          Rotation {
          }
          Scale {
            X: 1
            Y: 1
            Z: 1
          }
        }
        Folder {
          BundleDummy {
            ReferencedAssets {
              Id: 11745656537235251707
            }
          }
        }
        NetworkRelevanceDistance {
          Value: "mc:eproxyrelevance:critical"
        }
        IsReplicationEnabledByDefault: true
      }
    }
    PrimaryAssetId {
      AssetType: "None"
      AssetId: "None"
    }
  }
  Marketplace {
    Id: "72925892c183455782d91af2759518bd"
    OwnerAccountId: "d69d3d4a864e4c1d9c5a5bd7343c2daa"
    OwnerName: "ssamake"
    Version: "1.0.0"
    Description: "A SIMPLE HOUSE, this is my very first touch with CORE"
  }
  SerializationVersion: 125
}
