Assets {
  Id: 17798627266993350740
  Name: "ModuleManager"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
