Assets {
  Id: 3354819145114553317
  Name: "DestructibleWeaponClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
