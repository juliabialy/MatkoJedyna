Assets {
  Id: 16828847251705698173
  Name: "EquipmentStanceServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
