Assets {
  Id: 3132224522085315385
  Name: "Virtual Folders"
  PlatformAssetType: 30
  SerializationVersion: 125
  VirtualFolderSetAsset {
  }
}
