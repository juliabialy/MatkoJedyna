Assets {
  Id: 5938034728603880883
  Name: "LootBoxServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
