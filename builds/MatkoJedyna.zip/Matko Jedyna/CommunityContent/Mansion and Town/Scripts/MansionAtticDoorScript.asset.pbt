Assets {
  Id: 3930584335094505272
  Name: "MansionAtticDoorScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
