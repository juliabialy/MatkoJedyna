Assets {
  Id: 8927841499174147616
  Name: "BasicDoorControllerClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
