Assets {
  Id: 14403293984503380199
  Name: "APILootTable"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
