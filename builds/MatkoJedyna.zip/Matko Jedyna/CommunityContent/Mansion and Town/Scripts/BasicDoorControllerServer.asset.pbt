Assets {
  Id: 6898151438104399169
  Name: "BasicDoorControllerServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
