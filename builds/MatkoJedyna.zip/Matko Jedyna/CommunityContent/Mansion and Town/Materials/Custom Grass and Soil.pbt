Assets {
  Id: 11840763300774389320
  Name: "Custom Grass and Soil"
  PlatformAssetType: 13
  SerializationVersion: 125
  CustomMaterialAsset {
    BaseMaterialId: 884462330746487990
    ParameterOverrides {
      Overrides {
        Name: "material_scale"
        Float: 1
      }
    }
    Assets {
      Id: 884462330746487990
      Name: "Grass and Soil"
      PlatformAssetType: 2
      PrimaryAsset {
        AssetType: "MaterialAssetRef"
        AssetId: "mi_grass_003_uv"
      }
    }
  }
}
