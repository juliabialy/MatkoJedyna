Assets {
  Id: 2410885195540577147
  Name: "Mansion and Town"
  PlatformAssetType: 5
  TemplateAsset {
    ObjectBlock {
      RootId: 7343400729157546005
      Objects {
        Id: 7343400729157546005
        Name: "TemplateBundleDummy"
        Transform {
          Location {
          }
          Rotation {
          }
          Scale {
            X: 1
            Y: 1
            Z: 1
          }
        }
        CameraCollidable {
          Value: "mc:ecollisionsetting:inheritfromparent"
        }
        Folder {
          BundleDummy {
            ReferencedAssets {
              Id: 10861253452234383407
            }
          }
        }
        NetworkRelevanceDistance {
          Value: "mc:eproxyrelevance:critical"
        }
        IsReplicationEnabledByDefault: true
      }
    }
    PrimaryAssetId {
      AssetType: "None"
      AssetId: "None"
    }
  }
  Marketplace {
    Id: "c1d33582b1ed41d58f2c6df69b73bb84"
    OwnerAccountId: "9feae660d99b4fba8d14dac2503373d4"
    OwnerName: "Burnout"
    Version: "1.0.0"
    Description: "Mansion and town from Core Royale but without terrain"
  }
  SerializationVersion: 125
}
