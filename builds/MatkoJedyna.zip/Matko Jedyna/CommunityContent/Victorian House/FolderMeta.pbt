MetaVersion: 1
MarketplaceDetails {
  Id: "50d94895180c494db6eacfad670b9f2d"
  OwnerAccountId: "02b8b0373d2d4f1e8cf659d835e675b3"
  OwnerName: "elmartipro"
  Version: "1.0.0"
}
AssetIdsOriginalToNew {
  key: 3115364029915085189
  value: 17927028973409406407
}
AssetIdsOriginalToNew {
  key: 9033275411245414606
  value: 4772446013563578957
}
AssetIdsOriginalToNew {
  key: 17005688503312091142
  value: 10214577898556097551
}
AssetIdsOriginalToNew {
  key: 18197559403788611894
  value: 12659628277614132298
}
AssetIdsOriginalToNew {
  key: 18312569707859006031
  value: 3150600495521723113
}
