Assets {
  Id: 10071749959348780529
  Name: "CrossContextCaller"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
