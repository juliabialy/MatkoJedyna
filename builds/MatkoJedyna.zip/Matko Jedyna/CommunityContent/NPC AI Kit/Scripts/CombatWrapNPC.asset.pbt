Assets {
  Id: 10361807608143039713
  Name: "CombatWrapNPC"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:ModuleManager"
        AssetReference {
          Id: 8565240874411118340
        }
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
