Assets {
  Id: 10693029751351937724
  Name: "EnemyDefinitions"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:DataTable"
        AssetReference {
          Id: 16165101252532083926
        }
      }
    }
  }
  SerializationVersion: 125
}
