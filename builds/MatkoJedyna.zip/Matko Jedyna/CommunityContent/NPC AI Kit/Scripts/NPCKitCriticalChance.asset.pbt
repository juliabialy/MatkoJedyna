Assets {
  Id: 12582849810552513071
  Name: "NPCKitCriticalChance"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:Chance"
        Float: 0.2
      }
      Overrides {
        Name: "cs:Multiplier"
        Float: 2
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
