Assets {
  Id: 2274964348830950576
  Name: "DestructibleWeaponServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:ModuleManager"
        AssetReference {
          Id: 8565240874411118340
        }
      }
      Overrides {
        Name: "cs:DamageToPlayers"
        Int: 1
      }
      Overrides {
        Name: "cs:DamageToObjects"
        Int: 1
      }
      Overrides {
        Name: "cs:HeadshotNPCs"
        Int: 2
      }
      Overrides {
        Name: "cs:HeadshotPlayers"
        Int: 2
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
