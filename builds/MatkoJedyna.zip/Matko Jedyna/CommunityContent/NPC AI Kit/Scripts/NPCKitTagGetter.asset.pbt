Assets {
  Id: 215221127228871136
  Name: "NPCKitTagGetter"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
