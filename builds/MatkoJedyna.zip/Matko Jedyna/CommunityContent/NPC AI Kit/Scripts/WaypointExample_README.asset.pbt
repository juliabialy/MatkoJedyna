Assets {
  Id: 16927173380684413536
  Name: "WaypointExample_README"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
