Assets {
  Id: 9778789242663425470
  Name: "ExampleUndeadVulnerable"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:ModuleManager"
        AssetReference {
          Id: 8565240874411118340
        }
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
