Assets {
  Id: 2802363116473484742
  Name: "CombatWrapPlayer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
