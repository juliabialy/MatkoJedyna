Assets {
  Id: 9966849439598471554
  Name: "AmbushExample_README"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
