Assets {
  Id: 11353916028658914022
  Name: "CombatAccountant"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
