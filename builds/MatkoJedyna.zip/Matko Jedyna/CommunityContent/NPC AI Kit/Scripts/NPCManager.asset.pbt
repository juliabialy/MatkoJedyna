Assets {
  Id: 3831235013806929329
  Name: "NPCManager"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
