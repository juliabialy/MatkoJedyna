Assets {
  Id: 6757272573642457029
  Name: "NPC_KIT_README"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:NavMeshZonesExamples"
        AssetReference {
          Id: 5041171328252481044
        }
      }
      Overrides {
        Name: "cs:LeashZone"
        AssetReference {
          Id: 1213663261769199002
        }
      }
      Overrides {
        Name: "cs:NPCKitRespawnDamageablesInPlace"
        AssetReference {
          Id: 3534288197297062634
        }
      }
      Overrides {
        Name: "cs:NPCKitArmor"
        AssetReference {
          Id: 1226285646598577247
        }
      }
      Overrides {
        Name: "cs:NPCKitCriticalChance"
        AssetReference {
          Id: 12582849810552513071
        }
      }
      Overrides {
        Name: "cs:NPCKitEnemyHealthBarTop"
        AssetReference {
          Id: 7264911442829396036
        }
      }
      Overrides {
        Name: "cs:NPCKitEnemyData"
        AssetReference {
          Id: 11646651497989274081
        }
      }
      Overrides {
        Name: "cs:NPCKitAbilityBindings"
        AssetReference {
          Id: 16821032610562467982
        }
      }
      Overrides {
        Name: "cs:NPCKitTargetingSystem"
        AssetReference {
          Id: 4165770908147350954
        }
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
