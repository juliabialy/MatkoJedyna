Assets {
  Id: 2998519658137643422
  Name: "AnimatedMeshCostume"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
