Assets {
  Id: 3534288197297062634
  Name: "NPCKitRespawnDamageablesInPlace"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:RespawnDelay"
        Float: 10
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
