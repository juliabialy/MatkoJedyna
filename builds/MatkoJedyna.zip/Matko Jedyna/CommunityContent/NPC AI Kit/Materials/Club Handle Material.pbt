Assets {
  Id: 17842032415044427785
  Name: "Club Handle Material"
  PlatformAssetType: 13
  SerializationVersion: 125
  CustomMaterialAsset {
    BaseMaterialId: 2611942411954831737
    ParameterOverrides {
      Overrides {
        Name: "color"
        Color {
          R: 0.287
          G: 0.203064322
          B: 0.1435
          A: 1
        }
      }
    }
    Assets {
      Id: 2611942411954831737
      Name: "Cloth"
      PlatformAssetType: 2
      PrimaryAsset {
        AssetType: "MaterialAssetRef"
        AssetId: "mi_prop_urb_tools_detail_001_ref"
      }
    }
  }
}
