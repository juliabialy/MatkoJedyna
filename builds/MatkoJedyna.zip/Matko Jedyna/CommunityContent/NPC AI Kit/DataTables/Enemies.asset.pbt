Assets {
  Id: 16165101252532083926
  Name: "Enemies"
  PlatformAssetType: 31
  SerializationVersion: 125
  DataTableAsset {
    HasKeyColumn: true
  }
}
