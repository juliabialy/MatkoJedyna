Assets {
  Id: 17432824311796497817
  Name: "Custom Brush"
  PlatformAssetType: 34
  SerializationVersion: 125
  CustomBrushAsset {
    ImageId: "d4922374881f4250ade239c852408afc"
    CreatorId: "4db8cfcb307b411a95d329c7a484fe2a"
  }
}
