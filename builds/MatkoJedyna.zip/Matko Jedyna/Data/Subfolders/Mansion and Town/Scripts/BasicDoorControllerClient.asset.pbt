Assets {
  Id: 10344906603458936504
  Name: "BasicDoorControllerClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
