Assets {
  Id: 2528056123725522137
  Name: "BasicDoorControllerServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
