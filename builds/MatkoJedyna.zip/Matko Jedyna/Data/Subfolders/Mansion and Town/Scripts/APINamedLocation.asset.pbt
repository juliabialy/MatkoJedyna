Assets {
  Id: 6954067063903331146
  Name: "APINamedLocation"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
