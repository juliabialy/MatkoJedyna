Assets {
  Id: 12946389870966988151
  Name: "MansionAtticDoorScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
