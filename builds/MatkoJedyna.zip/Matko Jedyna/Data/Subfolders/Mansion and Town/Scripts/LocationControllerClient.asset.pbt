Assets {
  Id: 11677530305622856382
  Name: "LocationControllerClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
