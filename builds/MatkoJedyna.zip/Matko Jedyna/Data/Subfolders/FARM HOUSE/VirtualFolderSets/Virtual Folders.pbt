Assets {
  Id: 16741885839277034443
  Name: "Virtual Folders"
  PlatformAssetType: 30
  SerializationVersion: 125
  VirtualFolderSetAsset {
  }
}
