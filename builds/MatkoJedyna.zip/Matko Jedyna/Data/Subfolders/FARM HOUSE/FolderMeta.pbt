MetaVersion: 1
MarketplaceDetails {
  Id: "72925892c183455782d91af2759518bd"
  OwnerAccountId: "d69d3d4a864e4c1d9c5a5bd7343c2daa"
  OwnerName: "ssamake"
  Version: "1.0.0"
}
AssetIdsOriginalToNew {
  key: 9851993323794834176
  value: 4204711004328224358
}
AssetIdsOriginalToNew {
  key: 12835324764357373371
  value: 5543182977183949272
}
AssetIdsOriginalToNew {
  key: 14529539640068209619
  value: 1876114097719402295
}
