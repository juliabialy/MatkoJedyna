Assets {
  Id: 574309421887569403
  Name: "Enemies"
  PlatformAssetType: 31
  SerializationVersion: 125
  DataTableAsset {
    HasKeyColumn: true
  }
}
