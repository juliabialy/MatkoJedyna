Assets {
  Id: 16450513092557178012
  Name: "BasicDoorControllerClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
