Assets {
  Id: 5492138285035461038
  Name: "CellarDoorControlServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
