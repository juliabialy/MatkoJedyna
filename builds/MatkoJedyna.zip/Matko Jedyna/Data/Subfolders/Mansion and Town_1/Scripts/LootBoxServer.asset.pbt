Assets {
  Id: 3288198087657754002
  Name: "LootBoxServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
