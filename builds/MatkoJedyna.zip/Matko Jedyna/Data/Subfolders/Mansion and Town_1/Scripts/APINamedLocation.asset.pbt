Assets {
  Id: 12032199583831186432
  Name: "APINamedLocation"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
