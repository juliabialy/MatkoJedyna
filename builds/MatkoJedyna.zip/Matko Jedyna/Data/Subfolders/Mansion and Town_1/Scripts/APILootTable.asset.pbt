Assets {
  Id: 7021266884661665606
  Name: "APILootTable"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
