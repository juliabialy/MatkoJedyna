Assets {
  Id: 3553203489499834824
  Name: "MansionAtticDoorScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
