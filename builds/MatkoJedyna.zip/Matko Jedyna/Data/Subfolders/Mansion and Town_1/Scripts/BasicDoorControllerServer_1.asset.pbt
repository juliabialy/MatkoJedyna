Assets {
  Id: 9610703730069558271
  Name: "BasicDoorControllerServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
