Assets {
  Id: 12092597584216141791
  Name: "Custom Ceramic Tiles Octagon Dot 01_2"
  PlatformAssetType: 13
  SerializationVersion: 125
  CustomMaterialAsset {
    BaseMaterialId: 10041614114677710042
    ParameterOverrides {
      Overrides {
        Name: "u_tiles"
        Float: 2
      }
      Overrides {
        Name: "v_tiles"
        Float: 2
      }
      Overrides {
        Name: "variation"
        Float: 0
      }
      Overrides {
        Name: "material_scale"
        Float: 3
      }
      Overrides {
        Name: "accent_color"
        Color {
          G: 0.470000029
          B: 0.413973689
          A: 1
        }
      }
    }
    Assets {
      Id: 10041614114677710042
      Name: "Ceramic Tiles Octagon Dot 01"
      PlatformAssetType: 2
      PrimaryAsset {
        AssetType: "MaterialAssetRef"
        AssetId: "mi_ceramic_tile_square_002"
      }
    }
  }
}
