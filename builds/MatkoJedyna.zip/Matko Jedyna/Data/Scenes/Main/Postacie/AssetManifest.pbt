Assets {
  Id: 16404815372987981905
  Name: "Humanoid 1 Tight Jeans"
  PlatformAssetType: 26
  PrimaryAsset {
    AssetType: "SkinnedMeshAssetRef"
    AssetId: "npc_human_gal_lower_casual_002_ref"
  }
}
Assets {
  Id: 11906030156394461957
  Name: "Humanoid 1 Tennis Top"
  PlatformAssetType: 26
  PrimaryAsset {
    AssetType: "SkinnedMeshAssetRef"
    AssetId: "npc_human_gal_upper_sport_002_ref"
  }
}
Assets {
  Id: 8251088137577179069
  Name: "Humanoid 1 Rig"
  PlatformAssetType: 25
  PrimaryAsset {
    AssetType: "SkeletonAssetRef"
    AssetId: "npc_gal_wireframe_001_ref"
  }
}
Assets {
  Id: 444968792219948629
  Name: "Humanoid 1 Cassidy"
  PlatformAssetType: 26
  PrimaryAsset {
    AssetType: "SkinnedMeshAssetRef"
    AssetId: "npc_human_gal_head_basic_001_ref"
  }
}
