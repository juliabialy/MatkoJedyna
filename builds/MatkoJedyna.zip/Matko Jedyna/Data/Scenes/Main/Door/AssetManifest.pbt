Assets {
  Id: 10740239954750412532
  Name: "Craftsman Front Door 01"
  PlatformAssetType: 1
  PrimaryAsset {
    AssetType: "StaticMeshAssetRef"
    AssetId: "sm_urb_sub_craftsman_door_001"
  }
}
