Assets {
  Id: 205951603559882663
  Name: "Properties"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
