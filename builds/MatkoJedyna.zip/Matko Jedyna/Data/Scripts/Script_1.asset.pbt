Assets {
  Id: 3411318863666093807
  Name: "Script_1"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
