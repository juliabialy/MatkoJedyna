Assets {
  Id: 8068206496840998771
  Name: "FirstPersonCamera"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
