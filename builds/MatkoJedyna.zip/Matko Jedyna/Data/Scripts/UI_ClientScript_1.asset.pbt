Assets {
  Id: 3848750567081887345
  Name: "UI_ClientScript_1"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
