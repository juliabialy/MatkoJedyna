print("START")

local rig = script.parent
print("Parent name:", rig.name)
print("Parent type:", rig.type)

local pos = rig:GetWorldPosition()
print("POZYCJA OK", pos)

local newPos = pos + Vector3.New(300, 0, 0)
print("NEW POS OK", newPos)

rig:SetWorldPosition(newPos)
print("RUSZONY")