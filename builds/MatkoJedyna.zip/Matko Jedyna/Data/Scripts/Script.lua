local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

local mixCount = 0
local mixNeeded = 8
local finishedMixing = false

function OnInteracted(whichTrigger, player)
    if finishedMixing then
        UI.PrintToScreen("Ciasto już gotowe. Wystraczy włożyć do piekarnika!", Color.WHITE)
        return
    end

    mixCount = mixCount + 1
    UI.PrintToScreen("Mieszanie: " .. mixCount .. "/" .. mixNeeded, Color.WHITE)

    if mixCount >= mixNeeded then
        finishedMixing = true
        UI.PrintToScreen("Ciasto gotowe! ", Color.GREEN)
    end
end

function IsFinishedMixing()
    return finishedMixing
end

TRIGGER.interactedEvent:Connect(OnInteracted)