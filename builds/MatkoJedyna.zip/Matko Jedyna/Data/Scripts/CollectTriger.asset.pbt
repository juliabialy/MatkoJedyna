Assets {
  Id: 14114435915937797510
  Name: "CollectTriger"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
