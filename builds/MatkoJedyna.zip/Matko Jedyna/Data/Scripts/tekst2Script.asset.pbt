Assets {
  Id: 16027936704833924921
  Name: "tekst2Script"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
