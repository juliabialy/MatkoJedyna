Assets {
  Id: 17087014782581681604
  Name: "Script"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
