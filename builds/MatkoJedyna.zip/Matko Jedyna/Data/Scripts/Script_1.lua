local BOWL_SCRIPT = script:GetCustomProperty("Script"):WaitForObject()
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

local baking = false
local bakingTime = 0
local perfectMin = 4
local perfectMax = 7
local finishedGame = false

function OnInteracted(whichTrigger, player)
    if finishedGame then
        UI.PrintToScreen("Ciasto gotowe!", Color.GREEN)

        return
    end

    if not BOWL_SCRIPT.context.IsFinishedMixing() then
        UI.PrintToScreen("Najpierw wymieszaj ciasto w misce", Color.RED)
        return
    end

    if not baking then
        baking = true
        bakingTime = 0
        UI.PrintToScreen("Pieczenie rozpoczęte! ", Color.YELLOW)
        return
    end

    baking = false
    finishedGame = true

    if bakingTime < perfectMin then
        UI.PrintToScreen("Za wcześnie", Color.WHITE)
    elseif bakingTime <= perfectMax then
        UI.PrintToScreen("Idealne ", Color.GREEN)
    else
        UI.PrintToScreen("Spalone ", Color.RED)
    end
end

function Tick(deltaTime)
    if baking then
        bakingTime = bakingTime + deltaTime
    end
end

TRIGGER.interactedEvent:Connect(OnInteracted)