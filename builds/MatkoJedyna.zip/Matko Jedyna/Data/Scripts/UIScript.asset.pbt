Assets {
  Id: 16680882186556578902
  Name: "UIScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
