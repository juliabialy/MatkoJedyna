Assets {
  Id: 3861809090192723132
  Name: "DialogClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
