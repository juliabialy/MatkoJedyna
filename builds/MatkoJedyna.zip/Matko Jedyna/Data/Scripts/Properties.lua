local IMAGE = script:GETCustomProperty("UIImage"):WaitForObject()

local MENU = script.parent

IMAGE.clickedEvent:Connect(function()
	MENU.visibility = Visibility.FORCE_OFF
end)