Assets {
  Id: 5202976621167149062
  Name: "NewScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
