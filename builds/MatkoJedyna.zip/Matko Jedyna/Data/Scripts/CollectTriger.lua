local trigger = script.parent

-- ustaw ile jest wszystkich przedmiotów
local TOTAL_ITEMS = 5

function OnBeginOverlap(trigger, other)
    if not other:IsA("Player") then return end

    local player = other

    -- inicjalizacja punktów (tylko raz)
    if player:GetResource("Points") == nil then
        player:SetResource("Points", 0)
    end

    -- dodanie punktu
    player:AddResource("Points", 1)

    local points = player:GetResource("Points")

    print("Zebrano! Punkty: " .. points)

    -- update UI
    Events.BroadcastToPlayer(player, "UpdatePoints", points)

    -- 🔥 sprawdzenie czy to koniec gry
    if points >= TOTAL_ITEMS then
        
        local endTime = time()
        local duration = math.floor(endTime - _G.StartTime)

        local result = "Zły"
        if duration <= 10 then
            result = "Dobry"
        elseif duration <= 20 then
            result = "Średni"
        end

        Events.BroadcastToPlayer(player, "EndGame", duration, result)
    end

    -- usuń obiekt
    if trigger.parent then
        trigger.parent:Destroy()
    end
end

trigger.beginOverlapEvent:Connect(OnBeginOverlap)